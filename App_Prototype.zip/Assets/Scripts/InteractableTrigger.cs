using UnityEngine;

public class InteractableTrigger : MonoBehaviour
{
    public GameObject uiImage;
    private bool isPlayerInRange = false;
    private PlayerController playerController;

    void Update()
    {
        if (isPlayerInRange && Input.GetKeyDown(KeyCode.E))
        {
            if (uiImage != null)
            {
                uiImage.SetActive(true);

                // Freeze movement
                if (playerController != null)
                {
                    playerController.isFrozen = true;
                }

                // Enable the cursor for UI interaction
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInRange = true;
            playerController = other.GetComponent<PlayerController>(); // Get reference
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInRange = false;
            playerController = null;

            // Optional: hide UI and unfreeze when leaving
            if (uiImage != null)
                uiImage.SetActive(false);

            if (playerController != null)
                playerController.isFrozen = false;
        }
    }
}

